#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    char command[256];
    char *input = argv[1];
    int ret;

    printf("🔧 Running prog1 on %s...\n", input);
    snprintf(command, sizeof(command), "./c_analyzer %s", input);
    ret = system(command);
    if (ret != 0) printf("⚠️ prog1 exited with code %d\n", ret);

    printf("\n🔧 Running prog2 on %s...\n", input);
    snprintf(command, sizeof(command), "./checkerg < %s", input);
    ret = system(command);
    if (ret != 0) printf("⚠️ prog2 exited with code %d\n", ret);

    printf("\n🔧 Running prog3 on %s...\n", input);
    snprintf(command, sizeof(command), "./progp < %s", input);
    ret = system(command);
    if (ret != 0) printf("⚠️ prog3 exited with code %d\n", ret);

    printf("\n🔧 Running prog4 on %s...\n", input);
    snprintf(command, sizeof(command), "./checkers < %s", input);
    ret = system(command);
    if (ret != 0) printf("⚠️ prog4 exited with code %d\n", ret);

    printf("\n✅ All programs executed sequentially on %s.\n", input);
    return 0;
}

