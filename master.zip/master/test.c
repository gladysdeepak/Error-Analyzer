int global_var;
void compiler_errors_demo() {
    int a;
    float a;               // ⚠️ Redeclaration of variable

    int b;
    b = 10;
    c = 20;                // ⚠️ Use of undeclared variable

    int *p;
    *p = 5;                // ⚠️ Dereferencing uninitialized pointer (segfault)

    int d;
    d = b / 0;             // ⚠️ Division by zero

    int e;
    int f;
    f = e;                 // ⚠️ Use of uninitialized variable

    printf("%d %f %s", 10, 20.5); // ⚠️ Mismatch in printf arguments

    if (b < 5 && b > 50) { }      // ⚠️ Invalid if condition (logical contradiction)
   
   
        int b = 10;
    int a = 1;

    if (b & 1) { }         // ⚠️ Bitwise operator used instead of logical
    if (b > 0);             // ⚠️ Semicolon after if
        a = 1;              // Always runs
    if (b > 5)              // ⚠️ Missing braces
        b = 1;
        a = 2;              // Not part of if

    return;                 // ⚠️ Unreachable code below
    a = 10;
    b = 20;
}

/* 🧠 GROUP 1: Memory Lifecycle & Heap Management Errors */
void memory_errors_demo() {
    int *q;
    q = malloc(10);        // ⚠️ Missing NULL check
    free(q);
    free(q);               // ⚠️ Double free
    q = malloc(20);
    free(&q);              // ⚠️ Invalid free (not from malloc)
    int *leak = malloc(50); // ⚠️ Memory leak (never freed)
}

/* 🎯 GROUP 2: Pointer State & Dereferencing Errors */
int* return_local_pointer() {
    int local_x = 42;
    return &local_x;       // ⚠️ Returning pointer to local variable
}

void pointer_errors_demo() {
    int x;
    int *p;
    {
        int y;
        p = &y;            // ⚠️ Pointer to local scope
    }
    *p = 10;               // ⚠️ Dangling pointer (use after scope)

    int *dangling = malloc(sizeof(int));
    *dangling = 5;
    free(dangling);
    printf("%d\n", *dangling); // ⚠️ Use-after-free

    int *null_ptr = NULL;
    *null_ptr = 1;         // ⚠️ NULL pointer dereference

    int *uninit_ptr;
    *uninit_ptr = 3;       // ⚠️ Dereferencing uninitialized pointer

    int *bad_ret = return_local_pointer();
    printf("%d\n", *bad_ret); // ⚠️ Using pointer to local variable
}

/* 🛡️ GROUP 3: Buffer, String, and Array Security Errors */
void buffer_and_string_errors_demo() {
    int e[10];
    e[11] = 11;            // ⚠️ Array out of bounds

    char str[10];
    scanf("%s", str);      // ⚠️ Unsafe scanf (no width limit)

    strcpy(str, "this_string_is_too_long_for_buffer"); // ⚠️ Unsafe strcpy

    char *ro_str = "hello";
    ro_str[0] = 'H';       // ⚠️ Writing to read-only memory

    int n;
    scanf("%d", n);        // ⚠️ Missing & in scanf
}

/* ⚙️ GROUP 4: Logical & Control Flow Errors */
void logic_and_flow_errors_demo() {
    int b = 10;
    int a = 1;

    if (b & 1) { }         // ⚠️ Bitwise operator used instead of logical
    if (b > 0);             // ⚠️ Semicolon after if
        a = 1;              // Always runs
    if (b > 5)              // ⚠️ Missing braces
        b = 1;
        a = 2;              // Not part of if

    while (a < 20)
        b = 1;              // ⚠️ Unmodified loop variable (infinite loop)

    switch (a) {
        case 1:
            b = 10;         // ⚠️ Fallthrough
        case 2:
            b = 20;
            break;
    }

    return;                 // ⚠️ Unreachable code below
    a = 10;
    b = 20;
}

/* 🔢 GROUP 5: Function Call Errors */
int add(int x, int y) {
    int z = x + y;
    return z;
}

int no_return(int x) {
    int y = x + 1;
} // ⚠️ Missing return

float takes_int(int id) {
    return 10.5;
}

int bad_return_type() {
    return 10.5; // ⚠️ Return type mismatch
}

void function_call_errors_demo() {
    int result;
    float f_result;

    result = add(10);          // ⚠️ Wrong arg count
    result = add(1, 2, 3);     // ⚠️ Wrong arg count
    f_result = takes_int(10.5);// ⚠️ Wrong arg type
    result = no_return(5);     // ⚠️ Missing return used
}

/* MAIN — Runs all demos */
int main() {
    compiler_errors_demo();
    memory_errors_demo();
    pointer_errors_demo();
    buffer_and_string_errors_demo();
    logic_and_flow_errors_demo();
    function_call_errors_demo();

    // ⚠️ Invalid break outside loop/switch
    break;

    // ⚠️ Returning local variable address from main
    int x;
    return &x;
}
	

